package www.hi.demo123.com.sqlitedatabasedemo;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText roll,name,mark;
    Button insert,update,delete,search,select;

    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = openOrCreateDatabase("Student",MODE_PRIVATE,null);
        String tableQuery = "create table if  not exists record(roll varchar(255),name varchar(255),mark varchar(255))";
        db.execSQL(tableQuery);
        roll = (EditText) findViewById(R.id.roll);
        name = (EditText) findViewById(R.id.name);
        mark = (EditText) findViewById(R.id.mark);
        insert = (Button) findViewById(R.id.insert);
        update = (Button) findViewById(R.id.update);
        delete = (Button) findViewById(R.id.delete);
        search = (Button) findViewById(R.id.search);
        select = (Button) findViewById(R.id.select);

        select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String selectQuery = "select * from record";
                Cursor cursor = db.rawQuery(selectQuery,null);
                StringBuilder sb = new StringBuilder();
                if(cursor.moveToFirst()){
                    do {
                        sb.append("Name :\t"+cursor.getString(1)+"\t");
                        sb.append("Mark :\t"+cursor.getString(2)+"\n");
                    }
                    while (cursor.moveToNext());
                    Toast.makeText(MainActivity.this, sb, Toast.LENGTH_SHORT).show();
                }

            }
        });

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String searchQuery = "select * from record where roll='"+roll.getText().toString()+"'";
                Cursor cursor = db.rawQuery(searchQuery,null);
                if(cursor.moveToFirst()){
                    do {
                        name.setText(cursor.getString(1));
                        mark.setText(cursor.getString(2));
                    }
                    while (cursor.moveToNext());
                }
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String deleteQuery = "delete from record where roll='"+roll.getText().toString()+"'";
                db.execSQL(deleteQuery);
                Toast.makeText(MainActivity.this, "Record Delete Successfully", Toast.LENGTH_SHORT).show();
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String updateQuery = "update record set name='"+name.getText().toString()+"',mark='"+mark.getText().toString()+"' where roll='"+roll.getText().toString()+"'";
                db.execSQL(updateQuery);
                Toast.makeText(MainActivity.this, "Update Successfully", Toast.LENGTH_SHORT).show();
            }
        });

        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(roll.getText().toString().equalsIgnoreCase("")){
                    roll.setError("Roll No Required");
                    return;
                }
                else if(name.getText().toString().equalsIgnoreCase("")){
                    name.setError("Name Required");
                    return;
                }
                else if(mark.getText().toString().equalsIgnoreCase("")){
                    mark.setError("Mark Required");
                    return;
                }
                else{
                    String insertQuery = "insert into record values('"+roll.getText().toString()+"','"+name.getText().toString()+"','"+mark.getText().toString()+"')";
                    db.execSQL(insertQuery);
                    Toast.makeText(MainActivity.this, "Record Insert Successfully", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
