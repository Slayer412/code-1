package www.hi.demo123.com.tablayoutdemo;

import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    TabLayout tab;
    ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tab = (TabLayout) findViewById(R.id.tab);
        viewPager = (ViewPager) findViewById(R.id.viewpager);
        tab.post(new Runnable() {
            @Override
            public void run() {
                tab.setupWithViewPager(viewPager);
            }
        });
        viewPager.setAdapter(new MainAdapter(getSupportFragmentManager()));
    }

    private class MainAdapter extends FragmentPagerAdapter {
        public MainAdapter(FragmentManager supportFragmentManager) {
            super(supportFragmentManager);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position){
                case 0:
                    return "Call";
                case 1:
                    return "Chat";
                case 2:
                    return "Contact";
            }
            return null;
            //return super.getPageTitle(position);
        }

        @Override
        public Fragment getItem(int position) {
            switch (position){
                case 0:
                    return new CallFragment();
                case 1:
                    return new ChatFragment();
                case 2:
                    return new ContactFragment();
            }
            return null;
        }

        @Override
        public int getCount() {
            return 3;
        }
    }
}
