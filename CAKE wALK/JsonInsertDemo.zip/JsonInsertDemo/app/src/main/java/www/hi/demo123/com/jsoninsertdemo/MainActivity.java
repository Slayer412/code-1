package www.hi.demo123.com.jsoninsertdemo;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    EditText roll,name,mark;
    Button insert;
    String sroll,sname,smark;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        roll = (EditText) findViewById(R.id.roll);
        name = (EditText) findViewById(R.id.name);
        mark = (EditText) findViewById(R.id.mark);
        insert = (Button) findViewById(R.id.insert);

        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(new ConnectionCall(MainActivity.this).isConnectingToInternet()){
                    sroll = roll.getText().toString();
                    sname = name.getText().toString();
                    smark = mark.getText().toString();
                    new insertData().execute();
                }
                else{
                    new ConnectionCall(MainActivity.this).connectiondetect();
                }
            }
        });
    }

    private class insertData extends AsyncTask<String,String,String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(MainActivity.this);
            pd.setMessage("Loading...");
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String,String> hashMap = new HashMap<>();
            hashMap.put("roll",sroll);
            hashMap.put("name",sname);
            hashMap.put("mark",smark);
            return new MakeServiceCall().MakeServiceCall("http://192.168.0.106/record_insert.php",MakeServiceCall.POST,hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(pd.isShowing()){
                pd.dismiss();
            }
            try {
                JSONObject object = new JSONObject(s);
                if(object.getString("Status").equalsIgnoreCase("True")){
                    Toast.makeText(MainActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(MainActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
